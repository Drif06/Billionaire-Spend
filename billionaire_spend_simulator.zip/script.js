let billionaires = {
  ambani: {
    name: "Mukesh Ambani",
    money: 7000000000000,
    currency: "₹",
    locale: "en-IN"
  },
  adani: {
    name: "Gautam Adani",
    money: 5000000000000,
    currency: "₹",
    locale: "en-IN"
  },
  musk: {
    name: "Elon Musk",
    money: 250000000000,
    currency: "$",
    locale: "en-US"
  },
  bezos: {
    name: "Jeff Bezos",
    money: 180000000000,
    currency: "$",
    locale: "en-US"
  }
};

let selected = 'ambani';
let currentMoney = billionaires[selected].money;

function setBillionaire() {
  selected = document.getElementById("billionaire").value;
  currentMoney = billionaires[selected].money;
  updateDisplay();
}

function buyItem(cost) {
  if (currentMoney >= cost) {
    currentMoney -= cost;
    updateDisplay();
  } else {
    alert("You're out of money!");
  }
}

function updateDisplay() {
  let b = billionaires[selected];
  document.getElementById("money").innerText = currentMoney.toLocaleString(b.locale);
  document.getElementById("currency-label").innerHTML = `Wealth: ${b.currency}<span id="money">${currentMoney.toLocaleString(b.locale)}</span>`;
}
